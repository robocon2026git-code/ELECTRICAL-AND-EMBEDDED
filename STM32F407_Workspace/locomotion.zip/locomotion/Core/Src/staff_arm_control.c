/*
 * staff_arm_control.c
 *  Fixed: Direction change stops/restarts PWM properly
 *         Motor runs while button held, stops instantly on release
 *         EGR force update added to Stepper_SetSpeed (in user.c)
 */

#include <staff_arm_control.h>

int current_angle_p2 = STAFF_ARM_P2_INITIAL_ANGLE;
int current_angle_p3 = STAFF_ARM_P3_INITIAL_ANGLE;

int32_t target_steps_1  = 0;
int32_t current_steps_1 = 0;

void staff_arm_setup() {
    current_angle_p2 = STAFF_ARM_P2_INITIAL_ANGLE;
    current_angle_p3 = STAFF_ARM_P3_INITIAL_ANGLE;
    target_steps_1   = 0;
    current_steps_1  = 0;

    Servo_WriteAngle(&STAFF_ARM_P2_TIM_N, STAFF_ARM_P2_PULSE, (uint8_t)current_angle_p2);
    HAL_TIM_PWM_Start(&STAFF_ARM_P2_TIM_N, STAFF_ARM_P2_PULSE);
    HAL_Delay(150);

    Servo_WriteAngle(&STAFF_ARM_P3_TIM_N, STAFF_ARM_P3_PULSE, (uint8_t)current_angle_p3);
    HAL_TIM_PWM_Start(&STAFF_ARM_P3_TIM_N, STAFF_ARM_P3_PULSE);
    HAL_Delay(150);
}

void staff_arm_control() {
    uint32_t now = HAL_GetTick();
    static uint32_t last_servo_time  = 0;
    static uint32_t last_step_tick   = 0;
    static bool     pwm_running      = false;
    static bool     last_dir_cw      = true;

    // --- 1. STEPPER CONTROL ---
    // Motor runs ONLY while button held, stops instantly on release
    bool move_cw  = (btnStatus.triangle);
    bool move_ccw = (btnStatus.cross);

    if (move_cw || move_ccw) {
        bool dir_changed = (move_cw != last_dir_cw);

        // Stop PWM briefly if direction changed so driver latches new DIR
        if (dir_changed && pwm_running) {
            HAL_TIM_PWM_Stop(&STAFF_ARM_P1_TIM_N, STAFF_ARM_P1_PULSE);
            pwm_running = false;
            HAL_Delay(1);
        }

        // Set direction BEFORE starting PWM
        if (move_cw) {
            Stepper_SetDirection(STAFF_ARM_P1_DIR_PORT, STAFF_ARM_P1_DIR_PIN, CW);
            last_dir_cw = true;
        } else {
            Stepper_SetDirection(STAFF_ARM_P1_DIR_PORT, STAFF_ARM_P1_DIR_PIN, CCW);
            last_dir_cw = false;
        }

        // Start PWM only if not already running
        if (!pwm_running) {
            Stepper_SetSpeed(&STAFF_ARM_P1_TIM_N, STAFF_ARM_P1_PULSE, 1500);
            HAL_TIM_PWM_Start(&STAFF_ARM_P1_TIM_N, STAFF_ARM_P1_PULSE);
            pwm_running = true;
        }

        // Software position tracking (1ms tick = ~1000 steps/sec)
        if (now - last_step_tick >= 1) {
            last_step_tick = now;
            if (move_cw) {
                if (current_steps_1 < 671)  current_steps_1++;
            } else {
                if (current_steps_1 > -671) current_steps_1--;
            }
        }

    } else {
        // No button — stop motor immediately, hold position
        if (pwm_running) {
            HAL_TIM_PWM_Stop(&STAFF_ARM_P1_TIM_N, STAFF_ARM_P1_PULSE);
            pwm_running = false;
        }
        target_steps_1 = current_steps_1;
    }

    // --- 2. SERVO CONTROL (Every 20ms) ---
    if (now - last_servo_time >= 20) {
        last_servo_time = now;

        if (btnStatus.up) current_angle_p2 += STAFF_ARM_P2_STEP_ANGLE;
        if (btnStatus.down) current_angle_p2 -= STAFF_ARM_P2_STEP_ANGLE;

        if (btnStatus.left) current_angle_p3 += STAFF_ARM_P3_STEP_ANGLE;
        if (btnStatus.right) current_angle_p3 -= STAFF_ARM_P3_STEP_ANGLE;

        if (current_angle_p2 > 170) current_angle_p2 = 170;
        if (current_angle_p2 < 10)  current_angle_p2 = 10;
        if (current_angle_p3 > 180) current_angle_p3 = 180;
        if (current_angle_p3 < 0)   current_angle_p3 = 0;

        Servo_WriteAngle(&STAFF_ARM_P2_TIM_N, STAFF_ARM_P2_PULSE, (uint8_t)current_angle_p2);
        Servo_WriteAngle(&STAFF_ARM_P3_TIM_N, STAFF_ARM_P3_PULSE, (uint8_t)current_angle_p3);
    }
}

void Pnuematic_OnOff(uint8_t pneumatic_pin, uint8_t SET_RESET) {
    if (btnStatus.circle == 1) {
        HAL_GPIO_WritePin(PNEUMATIC_PORT, PNEUMATIC_PIN_1, SET);
        HAL_GPIO_WritePin(PNEUMATIC_PORT, PNEUMATIC_PIN_2, RESET);
    } else if (btnStatus.square == 1) {
        HAL_GPIO_WritePin(PNEUMATIC_PORT, PNEUMATIC_PIN_1, RESET);
        HAL_GPIO_WritePin(PNEUMATIC_PORT, PNEUMATIC_PIN_2, SET);
    }
}
