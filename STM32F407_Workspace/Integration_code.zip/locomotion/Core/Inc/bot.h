/*
 * bot.h
 *
 *  Created on: Jan 25, 2026
 *      Author: Admin
 */

#ifndef INC_BOT_H_
#define INC_BOT_H_


#include "user.h"
#include "locomotion.h"
#include "arm.h"



#endif /* INC_BOT_H_ */
